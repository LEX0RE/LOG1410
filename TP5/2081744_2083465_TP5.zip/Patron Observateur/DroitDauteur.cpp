
#include "DroitDauteur.hpp"
using namespace std;

void DroitDauteur::notification() {
	edition++;
}


