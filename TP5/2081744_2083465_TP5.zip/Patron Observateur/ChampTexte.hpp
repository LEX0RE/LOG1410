#pragma once

#include "Observateur.hpp"
#include <string>

class ChampTexte : public Observable {};